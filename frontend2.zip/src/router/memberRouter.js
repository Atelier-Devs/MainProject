import { lazy, Suspense } from "react";
import { Route } from "react-router-dom";

const Loading = <div>Loading...</div>;
const Login = lazy(() => import("../pages/member/LoginPage"));
const Signup = lazy(() => import("../pages/member/SignupForm"));

const MemberRouter = () => {
  return (
    <>
      <Route
        path="/login"
        element={
          <Suspense fallback={Loading}>
            <Login />
          </Suspense>
        }
      />
      <Route
        path="/signup"
        element={
          <Suspense fallback={Loading}>
            <Signup />
          </Suspense>
        }
      />
    </>
  );
};

export default MemberRouter;
