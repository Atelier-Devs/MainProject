import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import MemberRouter from "./router/memberRouter";
import MainPage from "./pages/MainPage";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MainPage />} />
        {MemberRouter()}
      </Routes>
    </Router>
  );
};

export default App;
