import React from "react";
import { useNavigate } from "react-router-dom";
import Header from "../../components/Header";
import Footer from "../../components/Footer";

const Reservation = () => {
    const navigate = useNavigate();

    return (
        <div className="flex flex-col min-h-screen">
            <Header />

            <div
                className="flex flex-col items-center justify-center flex-grow bg-cover bg-center bg-no-repeat"
                style={{ backgroundImage: "url('')" }}
            >
                <div className="bg-white bg-opacity-80 p-8 rounded-lg shadow-lg max-w-md w-full">
                    <h1 className="text-3xl font-bold text-[#cea062] mb-4 text-center">
                        예약 조회
                    </h1>
                    <h2 className="text-xl text-[#ad9e87] mb-6 text-center">
                        예약 정보를 입력하세요
                    </h2>

                    <form className="flex flex-col gap-4">
                        <div>
                            <label htmlFor="reservationId" className="font-semibold text-[#cea062]">
                                예약 번호
                            </label>
                            <input
                                className="w-full h-10 px-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#cea062] focus:outline-none"
                                type="text"
                                id="reservationId"
                                name="reservationId"
                                placeholder="예약 번호를 입력하세요"
                                required
                            />
                        </div>

                        <button
                            type="submit"
                            className="w-full bg-[#b89c7d] text-white font-bold py-2 rounded-md hover:bg-[#a58b6a] transition-all duration-300"
                        >
                            조회하기
                        </button>
                    </form>
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default Reservation;
