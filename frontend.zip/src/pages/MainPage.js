import React from "react";

const MainPage = () => {
  console.log("여기 떠라 ");
  return <div>MainPage</div>;
};

export default MainPage;
