package com.example.atelier.repository;

import com.example.atelier.domain.Log;
import com.example.atelier.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LogRepository extends JpaRepository<Log,Integer> {
    List<Log> findByUserId(User user);
}
