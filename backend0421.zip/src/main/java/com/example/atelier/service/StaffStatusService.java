package com.example.atelier.service;

import com.example.atelier.dto.ResidenceStatDTO;
import com.example.atelier.dto.StaffStatusDTO;
import com.example.atelier.dto.UserStatDTO;

import java.math.BigDecimal;
import java.util.List;


public interface StaffStatusService {

    public StaffStatusDTO getStaffStatus();
}
