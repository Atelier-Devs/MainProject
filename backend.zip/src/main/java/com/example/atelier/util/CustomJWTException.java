package com.example.atelier.util;

public class CustomJWTException extends RuntimeException{
    public CustomJWTException(String message) {
        super(message);
    }
}
